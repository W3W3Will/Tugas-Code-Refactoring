package CommentAfter;

public class Calculator {

	public class calculator {
		public int add(int num1, int num2) {
			return num1+num2;
		}
		public int multitply(int num1, int num2){
			return num1*num2;
		}
		public int subtract(int num1, int num2) {
			return num1-num2;
		}
		public double divide(int num1, int num2) {
			return num1/num2;
		}
	}
}
