package CommentBefore;

public class calculator {
	//parameter a is the first number
	//parameter b is the second number
	//the add function adds the first and the second number
	public int add(int a, int b) {
		return a+b;
	}
	//this function multiplies the first with the second number
	public int multitply(int a, int b){
		return a*b;
	}
	//this function subtracts the first by second number
	public int subtract(int a, int b) {
		return a-b;
	}
	//divides the first by second number
	public double divide(int a, int b) {
		return a/b;
	}
}
