public class Order {
    private String itemId;
    private int quantity;
    private double price;

    public Order(String itemId, int quantity, double price) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.price = price;
    }

    public double getTotalPrice() {
        return quantity * price;
    }

    public String toString() {
        return "Item: " + itemId + ", Quantity: " + quantity + ", Price: " + price;
    }
}


public static void main(String[] args) {
    Order order1 = new Order("123", 5, 12.99);
    System.out.println(order1);
    System.out.println("Total price: $" + order1.getTotalPrice());

    Order order2 = new Order("456", 10, 6.99);
    System.out.println(order2);
    System.out.println("Total price: $" + order2.getTotalPrice());
}