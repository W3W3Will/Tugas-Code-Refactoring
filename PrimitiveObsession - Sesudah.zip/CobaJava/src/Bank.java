public class Order {
    private String itemId;
    private int quantity;
    private double price;

    public Order(String itemId, int quantity, double price) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.price = price;
    }

    public double getTotalPrice() {
        return quantity * price;
    }

    public String toString() {
        return "Item: " + itemId + ", Quantity: " + quantity + ", Price: " + price;
    }
}


public static void main(String[] args) {
    Order order1 = new Order("123", 5, 12.99);
    System.out.println(order1);
    System.out.println("Total price: $" + order1.getTotalPrice());

    Order order2 = new Order("456", 10, 6.99);
    System.out.println(order2);
    System.out.println("Total price: $" + order2.getTotalPrice());
}


public class Bank {
    public static class Item {
        private String id;
        private double price;

        public Item(String id, double price) {
            this.id = id;
            this.price = price;
        }

        public String getId() {
            return id;
        }

        public double getPrice() {
            return price;
        }
    }

    public static class Order {
        private Item item;
        private int quantity;

        public Order(Item item, int quantity) {
            this.item = item;
            this.quantity = quantity;
        }

        public double getTotalPrice() {
            return quantity * item.getPrice();
        }

        public String toString() {
            return "Item: " + item.getId() + ", Quantity: " + quantity + ", Price: " + item.getPrice();
        }
    }

    public static void main(String[] args) {
        Item item1 = new Item("123", 12.99);
        Order order1 = new Order(item1, 5);
        System.out.println(order1);
        System.out.println("Total price: $" + order1.getTotalPrice());

        Item item2 = new Item("456", 6.99);
        Order order2 = new Order(item2, 10);
        System.out.println(order2);
        System.out.println("Total price: $" + order2.getTotalPrice());
    }
}